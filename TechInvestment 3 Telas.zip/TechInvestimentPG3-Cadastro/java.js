function paginaMenu(){
    window.location.href="paginaMenu.html"
}