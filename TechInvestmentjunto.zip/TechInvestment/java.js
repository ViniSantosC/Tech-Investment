function paginaLogin(){
    window.location.href='login.html'
}

function paginaCadastro (){
    window.location.href='Cadastro.html'
}